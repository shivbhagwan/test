#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using namespace::std;

/*
 *	Sorts input strings using the std::sort function. Hence the complexity is O(nLog(n))
 */

bool compare(const string &a, const string &b) {
	return a.size() < b.size();
}

int main()
{
	int n, i;
	string input;
	vector <string> output;

	cout << "Enter number of strings ";
	cin >> n;

	for (i = 0; i < n; i++)
	{
		cout << "Enter string: " << i <<" ";
		cin >> input;
		output.push_back(input);
	}

	sort(output.begin(), output.end(), compare);
	
	cout << "Strings in sorted order are" << endl;
	for (i = 0; i < n; i++)
		cout << output[i] << endl;
	return 0;
}